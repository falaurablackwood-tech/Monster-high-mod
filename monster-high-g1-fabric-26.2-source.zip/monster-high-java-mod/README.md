# Monster High: New Salem

An unofficial fan-made **Fabric mod for Minecraft Java 26.2**. All included textures are original placeholders; no assets were extracted from Monster High games, shows, or merchandise.

## Features in 0.1.0

- Friendly Draculaura, Frankie, Clawdeen, Cleo, Ghoulia, Lagoona, and Abbey NPCs
- Character spawn eggs and short click-to-talk dialogue
- Purple bricks, glowing floor tiles, and haunted lockers
- iCoffin tablet and scream cheese items
- `/monsterhigh campus` command for operators, which builds a gothic school courtyard nearby
- Dedicated creative-mode tab

## Build and play

1. Install a 64-bit **JDK 25**.
2. Install Fabric Loader 0.19.5 and Fabric API 0.160.0 for Minecraft 26.2.
3. Open this folder in IntelliJ IDEA, or install a current Gradle release.
4. Run `gradle runClient` to test, or `gradle build` to create the JAR.
5. Put the JAR from `build/libs/` and Fabric API into the `mods` folder of a Fabric 26.2 installation.

If you generate a Gradle wrapper, commit `gradlew`, `gradlew.bat`, and `gradle/wrapper/` so other contributors can build with `./gradlew build`.

## Legal note

Monster High and its characters are trademarks/copyrighted properties of Mattel. This noncommercial fan project is not endorsed by Mattel. Distribute only original code and artwork, and follow Mattel's fan-content rules.
