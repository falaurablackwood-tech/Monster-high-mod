package com.christianvampso.monsterhigh;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

public final class CampusCommand {
    private CampusCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("monsterhigh")
                .then(Commands.literal("campus").requires(source -> source.hasPermission(2)).executes(context -> {
                    buildCampus(context.getSource().getLevel(), BlockPos.containing(context.getSource().getPosition()).offset(5, 0, 5));
                    context.getSource().sendSuccess(() -> Component.literal("Monster High courtyard built nearby."), true);
                    return 1;
                })));
    }

    private static void buildCampus(ServerLevel level, BlockPos origin) {
        int width = 25, depth = 19, wallHeight = 8;
        for (int x = 0; x < width; x++) for (int z = 0; z < depth; z++) {
            level.setBlockAndUpdate(origin.offset(x, -1, z), MonsterHighMod.SKULLETTE_TILES.get().defaultBlockState());
        }
        for (int y = 0; y < wallHeight; y++) for (int x = 0; x < width; x++) {
            placeWall(level, origin.offset(x, y, 0), x, y, width);
            placeWall(level, origin.offset(x, y, depth - 1), x, y, width);
        }
        for (int y = 0; y < wallHeight; y++) for (int z = 1; z < depth - 1; z++) {
            placeWall(level, origin.offset(0, y, z), z, y, depth);
            placeWall(level, origin.offset(width - 1, y, z), z, y, depth);
        }
        int doorX = width / 2;
        for (int x = doorX - 1; x <= doorX + 1; x++) for (int y = 0; y < 4; y++)
            level.setBlockAndUpdate(origin.offset(x, y, 0), Blocks.AIR.defaultBlockState());
        for (int x = 2; x < width - 2; x += 4)
            level.setBlockAndUpdate(origin.offset(x, 1, 1), MonsterHighMod.HAUNTED_LOCKER.get().defaultBlockState());
        level.setBlockAndUpdate(origin.offset(doorX, wallHeight + 2, 0), MonsterHighMod.SKULLETTE_TILES.get().defaultBlockState());
    }

    private static void placeWall(ServerLevel level, BlockPos pos, int along, int y, int length) {
        boolean window = y >= 2 && y <= 4 && along % 6 >= 2 && along % 6 <= 3;
        level.setBlockAndUpdate(pos, window ? Blocks.PURPLE_STAINED_GLASS.defaultBlockState() : MonsterHighMod.PURPLE_BRICKS.get().defaultBlockState());
    }
}
