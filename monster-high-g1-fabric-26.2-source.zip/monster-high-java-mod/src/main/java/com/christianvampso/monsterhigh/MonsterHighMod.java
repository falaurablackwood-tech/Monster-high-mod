package com.christianvampso.monsterhigh;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;

public final class MonsterHighMod implements ModInitializer {
    public static final String MOD_ID = "monsterhigh";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final Block PURPLE_BRICKS = block("purple_bricks", BlockBehaviour.Properties.of().strength(2, 6));
    public static final Block SKULLETTE_TILES = block("skullette_tiles", BlockBehaviour.Properties.of().strength(1.5F, 6).lightLevel(s -> 4));
    public static final Block HAUNTED_LOCKER = block("haunted_locker", BlockBehaviour.Properties.of().strength(2.5F).noOcclusion());
    public static final Item ICLOSET_TABLET = item("icloset_tablet", new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
    public static final Item SCREAM_CHEESE = item("scream_cheese", new Item.Properties().food(new FoodProperties.Builder().nutrition(6).saturationModifier(0.7F).build()));

    public static final List<CharacterProfile> PROFILES = List.of(
        new CharacterProfile("draculaura", "Draculaura", "Fangtastic! Welcome to New Salem!"),
        new CharacterProfile("frankie", "Frankie Stein", "Voltageous! The science lab is this way."),
        new CharacterProfile("clawdeen", "Clawdeen Wolf", "This campus needs clawsome style."),
        new CharacterProfile("cleo", "Cleo de Nile", "The royal hallway must look perfect."),
        new CharacterProfile("ghoulia", "Ghoulia Yelps", "Brains, books, and good grades."),
        new CharacterProfile("lagoona", "Lagoona Blue", "The pool is totally fin-tastic today!"),
        new CharacterProfile("abbey", "Abbey Bominable", "Cold weather builds strong character.")
    );
    public static final List<EntityType<MonsterStudentEntity>> STUDENTS = new ArrayList<>();
    public static final List<Item> SPAWN_EGGS = new ArrayList<>();
    public static final CreativeModeTab TAB = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("monster_high"),
        FabricItemGroup.builder().title(Component.translatable("itemGroup.monsterhigh")).icon(ICLOSET_TABLET::getDefaultInstance).build());

    @Override public void onInitialize() {
        for (CharacterProfile profile : PROFILES) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id(profile.id()));
            EntityType<MonsterStudentEntity> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, key,
                EntityType.Builder.<MonsterStudentEntity>of((t, level) -> new MonsterStudentEntity(t, level, profile), MobCategory.CREATURE)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build(key));
            STUDENTS.add(type);
            FabricDefaultAttributeRegistry.register(type, Zombie.createAttributes().add(Attributes.MAX_HEALTH, 20).add(Attributes.MOVEMENT_SPEED, 0.25).add(Attributes.ATTACK_DAMAGE, 0));
            ResourceKey<Item> eggKey = ResourceKey.create(Registries.ITEM, id(profile.id() + "_spawn_egg"));
            SPAWN_EGGS.add(Registry.register(BuiltInRegistries.ITEM, eggKey, new SpawnEggItem(type, new Item.Properties().setId(eggKey))));
        }
        ItemGroupEvents.modifyEntriesEvent(TAB).register(entries -> {
            entries.accept(PURPLE_BRICKS.asItem()); entries.accept(SKULLETTE_TILES.asItem()); entries.accept(HAUNTED_LOCKER.asItem());
            entries.accept(ICLOSET_TABLET); entries.accept(SCREAM_CHEESE); SPAWN_EGGS.forEach(entries::accept);
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> CampusCommand.register(dispatcher));
        LOGGER.info("Loaded {} classic G1 ghouls for Fabric 26.2", PROFILES.size());
    }

    private static Block block(String path, BlockBehaviour.Properties properties) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, id(path));
        Block value = Registry.register(BuiltInRegistries.BLOCK, key, new Block(properties.setId(key)));
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id(path));
        Registry.register(BuiltInRegistries.ITEM, itemKey, new BlockItem(value, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
        return value;
    }
    private static Item item(String path, Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(path));
        return Registry.register(BuiltInRegistries.ITEM, key, new Item(properties.setId(key)));
    }
    public static Identifier id(String path) { return Identifier.fromNamespaceAndPath(MOD_ID, path); }
    public record CharacterProfile(String id, String displayName, String greeting) {}

    public static final class MonsterStudentEntity extends Zombie {
        private final CharacterProfile profile;
        public MonsterStudentEntity(EntityType<? extends Zombie> type, Level level, CharacterProfile profile) {
            super(type, level); this.profile = profile; setCustomName(Component.literal(profile.displayName())); setCustomNameVisible(true); setPersistenceRequired();
        }
        public CharacterProfile profile() { return profile; }
        @Override protected void registerGoals() {
            goalSelector.addGoal(0, new net.minecraft.world.entity.ai.goal.FloatGoal(this));
            goalSelector.addGoal(5, new net.minecraft.world.entity.ai.goal.RandomStrollGoal(this, 0.8));
            goalSelector.addGoal(6, new net.minecraft.world.entity.ai.goal.LookAtPlayerGoal(this, Player.class, 8));
            goalSelector.addGoal(7, new net.minecraft.world.entity.ai.goal.RandomLookAroundGoal(this));
        }
        @Override public boolean isSunSensitive() { return false; }
        @Override public boolean doHurtTarget(Entity target) { return false; }
        @Override protected InteractionResult mobInteract(Player player, InteractionHand hand) {
            if (!level().isClientSide()) player.displayClientMessage(Component.literal("<" + profile.displayName() + "> " + profile.greeting()), false);
            return InteractionResult.SUCCESS;
        }
        @Override public boolean canAttackType(EntityType<?> type) { return false; }
    }
}
