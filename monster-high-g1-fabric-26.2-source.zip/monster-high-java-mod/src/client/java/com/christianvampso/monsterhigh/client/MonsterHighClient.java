package com.christianvampso.monsterhigh.client;

import com.christianvampso.monsterhigh.MonsterHighMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.monster.Zombie;

public final class MonsterHighClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        MonsterHighMod.STUDENTS.forEach(type -> EntityRendererRegistry.register(type, StudentRenderer::new));
    }
    private static final class StudentRenderer extends ZombieRenderer {
        StudentRenderer(net.minecraft.client.renderer.entity.EntityRendererProvider.Context context) { super(context); }
        @Override public Identifier getTextureLocation(Zombie entity) {
            String id = ((MonsterHighMod.MonsterStudentEntity) entity).profile().id();
            return MonsterHighMod.id("textures/entity/" + id + ".png");
        }
    }
}
